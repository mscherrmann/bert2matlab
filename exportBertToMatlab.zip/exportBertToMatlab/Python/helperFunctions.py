# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 15:14:19 2023

@author: scherrmann
"""
from scipy.io import savemat
import numpy as np
import re
import os
from transformers import AutoTokenizer

def saveBertWeights(mdl,tokenizer,mdlStr,framework,modelPath="..\\Models"):
    saveStr = mdlStr
    if "GermanFinBERT" in saveStr:
        if "BaseModels" in saveStr:
            saveStr = saveStr.split("BaseModels")[-1]
            saveStr = saveStr.replace("\\","/")
        else:
            saveStr = saveStr.split("Finetuning")[-1]
            saveStr = saveStr.replace("\\","/")
    if not os.path.exists(modelPath+"\\"+framework+"\\"+saveStr):
        os.makedirs(modelPath+"\\"+framework+"\\"+saveStr)
    tokenizer.save_vocabulary(modelPath+"\\"+framework+"\\"+saveStr)
    ignoreCase=tokenizer.do_lower_case # Is the model case senstitive?
    stripAccents=tokenizer.backend_tokenizer.normalizer.strip_accents # Is the model case senstitive?
    if stripAccents is None:
        if ignoreCase:
            stripAccents = True
        else:
            stripAccents = False
    
    # Get Model Specification
    if framework=="tf":
        bertConfig=mdl.bert.get_config() # Get model config
        weights=mdl.weights # Get weights of model
    else:
        bertConfig=mdl.config
        weights=list(mdl.named_parameters()) # Get weights of model
    
    # Store model weights and additional info to malab file
    modelParams={}
    if framework=="tf":
        modelParams["Name"]=re.sub('_\d+$', '', mdl.name)
        modelParams["ClassName"]=type(mdl).__name__
        modelParams["Hyperparameters__NumHeads"]=bertConfig["config"]["num_attention_heads"]
        modelParams["Hyperparameters__NumLayers"]=bertConfig["config"]['num_hidden_layers']
        modelParams["Hyperparameters__NumContext"]=bertConfig["config"]['max_position_embeddings']
        modelParams["Hyperparameters__HiddenSize"]=bertConfig["config"]["intermediate_size"]
        modelParams["Hyperparameters__EmbeddingDimension"]=bertConfig["config"]['hidden_size']
        modelParams["Hyperparameters__NormEps"]=bertConfig["config"]["layer_norm_eps"]
        if "TokenClassification" in type(mdl).__name__:
            modelParams["Hyperparameters__TokenEntities"]=np.array(list(mdl.get_config()["id2label"].values()))
        if "SequenceClassification" in type(mdl).__name__:
            modelParams["Hyperparameters__TextEntities"]=np.array(list(mdl.get_config()["id2label"].values()))
    else:
        modelParams["Name"]=re.sub('_\d+$', '', mdl.name_or_path)
        modelParams["ClassName"]=type(mdl).__name__
        modelParams["Hyperparameters__NumHeads"]=bertConfig.num_attention_heads
        modelParams["Hyperparameters__NumLayers"]=bertConfig.num_hidden_layers
        modelParams["Hyperparameters__NumContext"]=bertConfig.max_position_embeddings
        modelParams["Hyperparameters__HiddenSize"]=bertConfig.intermediate_size
        modelParams["Hyperparameters__EmbeddingDimension"]=bertConfig.hidden_size
        modelParams["Hyperparameters__NormEps"]=bertConfig.layer_norm_eps
        if "TokenClassification" in type(mdl).__name__:
            modelParams["Hyperparameters__TokenEntities"]=np.array(list(mdl.config.id2label.values()))
        if "SequenceClassification" in type(mdl).__name__:
            modelParams["Hyperparameters__TextEntities"]=np.array(list(mdl.config.id2label.values()))
    modelParams["Hyperparameters__IgnoreCase"]=ignoreCase
    modelParams["Hyperparameters__StripAccents"]=stripAccents
    
    for w in weights:
        if framework=="tf":
            name=w.name
            name=re.sub('.+/bert/', '', name)
            name=name.replace("/","__")
            name=re.sub(":\d+","",name)
            name=re.sub('_\._', '__', name)
            name=re.sub("tf_bert_for_sequence_classification_\d+__classifier","sequenceClassifier",name)
            name=re.sub("tf_bert_for_token_classification_\d+__classifier","tokenClassifier",name)
            modelParams[name]=np.transpose(w.numpy())
        else:
            name=w[0]
            name=name.replace(".","__")
            name=name.replace("bert__","")
            name=name.replace("mpnet__","")
            name=name.replace("LayerNorm__bias","LayerNorm__beta")
            name=name.replace("LayerNorm__weight","LayerNorm__gamma")
            name=name.replace("embeddings__position_embeddings__weight","embeddings__position_embeddings__embeddings")
            name=name.replace("attention__attn","attention__self")
            name=name.replace("__k__","__key__")
            name=name.replace("__q__","__query__")
            name=name.replace("__v__","__value__")
            name=name.replace("__weight","__kernel")
            name=name.replace("embeddings__word_embeddings__kernel","embeddings__word_embeddings__weight")
            name=name.replace("attention__self__o","attention__output__dense")
            name=name.replace("attention__LayerNorm","attention__output__LayerNorm")
            name=name.replace("embeddings__token_type_embeddings__kernel","embeddings__token_type_embeddings__embeddings")
            if "TokenClassification" in type(mdl).__name__:
                name=name.replace("classifier__kernel","tokenClassifier__kernel")
                name=name.replace("classifier__bias","tokenClassifier__bias")
            if "SequenceClassification" in type(mdl).__name__:
                name=name.replace("classifier__kernel","sequenceClassifier__kernel")
                name=name.replace("classifier__bias","sequenceClassifier__bias")
            # In pytorch models, some weight matrices are tranposed
            if name in ["embeddings__token_type_embeddings__embeddings","embeddings__position_embeddings__embeddings","embeddings__word_embeddings__weight","encoder__relative_attention_bias__kernel"]:
                modelParams[name]=np.transpose(w[1].detach().numpy())
            else:
                modelParams[name]=w[1].detach().numpy()
    # MPNET models do not have any token type embeddings. Add them as zero matrices
    if "mpnet" in mdlStr:
        modelParams["embeddings__token_type_embeddings__embeddings"]=np.zeros((768,2)) 
    savemat(modelPath+"\\"+framework+"\\"+saveStr+"\\matlab_bert_params.mat", modelParams)
    
def getModelAndTokenizer(mdlStr,downstreamTask,framework,tokenizerStr=None):
    if not tokenizerStr:
        tokenizerStr = mdlStr
    if downstreamTask:
        try:
            from transformers import pipeline
            classifier = pipeline(downstreamTask, model = mdlStr,framework=framework,tokenizer = tokenizerStr)
        except:
            if framework=="tf":
                raise Exception('Model not available for Tensorflow')
            else:
                raise Exception('Model not available for PyTorch')
        tokenizer=classifier.tokenizer
        mdl=classifier.model
    else:
        tokenizer =AutoTokenizer.from_pretrained(tokenizerStr)
        if framework=="pt":
            from transformers import AutoModel
            try:
                mdl = AutoModel.from_pretrained(mdlStr)
            except:
                raise Exception('Model not available for PyTorch')
        else:
            from transformers import TFAutoModel
            try:
                mdl = TFAutoModel.from_pretrained(mdlStr)
            except:
                raise Exception('Model not available for Tensorflow')
    return [mdl,tokenizer]
    saveBertWeights(mdl,tokenizer,mdlStr,framework)
    
def modelToMatlab(mdlStr,downstreamTask,framework,tokenizerStr = None):
    [mdl,tokenizer]=getModelAndTokenizer(mdlStr,downstreamTask,framework, tokenizerStr)
    saveBertWeights(mdl,tokenizer,mdlStr,framework)

