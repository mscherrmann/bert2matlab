# -*- coding: utf-8 -*-
"""
Created on Wed Feb 22 13:30:10 2023

@author: scherrmann
"""

from helperFunctions import getModelAndTokenizer
import numpy as np
import pandas as pd
#%% Get Model
#   BERT for NER (downstreamTask="token-classification"):
#   - "philschmid/gbert-base-germaner" (tf) (German)
#   - "tner/bert-base-tweetner7-2020" (pt) (English)

mdlStr="tner/bert-base-tweetner7-2020"
downstreamTask="token-classification"
framework="pt"
language="English" # "German", "English" (Depending on model)
[mdl,tokenizer]=getModelAndTokenizer(mdlStr,downstreamTask,framework)


#%% Examples
if language=="English":
    sentences= ["Get the all-analog Classic Vinyl Edition of `Takin' Off` Album from {@herbiehancock@} via {@bluenoterecords@} link below: {{URL}}"]
else:
    sentences=["Volkswagen ist die Kernmarke der Volkswagen AG."]

if framework=="tf":
    import tensorflow as tf
    tokens = tokenizer(
        sentences,
        padding="longest",
        pad_to_max_length=True,
        truncation=True
    )
    input_ids = tf.convert_to_tensor(tokens['input_ids'])
    token_type_ids = tf.convert_to_tensor(tokens['token_type_ids'])
    attention_mask = tf.convert_to_tensor(tokens['attention_mask'])
    output=mdl(input_ids=input_ids,token_type_ids=token_type_ids,attention_mask=attention_mask)
    o=np.squeeze(tf.nn.softmax(output.logits).numpy())
    input_ids=input_ids.numpy()
else:
    import torch
    tokens = tokenizer(sentences,
        padding="longest",
        pad_to_max_length=True,
        truncation=True, return_tensors='pt')
    # Compute token embeddings
    with torch.no_grad():
        output = mdl(**tokens)
    input_ids =np.array(tokens['input_ids'][0])
    o=np.squeeze(torch.nn.functional.softmax(output.logits,dim=2).numpy())
labelId=np.squeeze(np.argmax(o,axis=1))
scores=np.max(o,axis=1)
if framework=="tf":
    prediction=[mdl.get_config()["id2label"][idx] for idx in labelId]
else:
    prediction=[mdl.config.id2label[idx] for idx in labelId]
toks=tokenizer.convert_ids_to_tokens(np.squeeze(input_ids))
frame=pd.DataFrame({"Tokens":toks,"Enitity":prediction,"Score":scores})
print(frame)