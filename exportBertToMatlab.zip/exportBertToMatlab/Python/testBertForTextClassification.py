# -*- coding: utf-8 -*-
"""
Created on Wed Feb 22 13:30:39 2023

@author: scherrmann
"""

from helperFunctions import getModelAndTokenizer
import numpy as np
#%% Get Model
#   BERT for Sentiment (downstreamTask="text-classification"):
#   - "nickmuchi/sec-bert-finetuned-finance-classification" (pt) (English)
#   - "oliverguhr/german-sentiment-bert" (tf + pt) (German)

mdlStr="nickmuchi/sec-bert-finetuned-finance-classification"
downstreamTask="text-classification"
framework="pt"
[mdl,tokenizer]=getModelAndTokenizer(mdlStr,downstreamTask,framework)


#%% Examples
language="English" # "German", "English" (Depending on model)
if language=="English":
    sentences= ["The USD rallied by 10% last night",
                "Covid-19 cases have been increasing over the past few months impacting earnings for global firms",
                "Dividend maintained at CHF 4.00"]
else:
    sentences=["Ich bin sehr glücklich.",
            "Ich bin sehr traurig.",
            "Eine Zange ist ein Werkzeug"]

if framework=="tf":
    import tensorflow as tf
    tokens = tokenizer(
        sentences,
        padding="longest",
        pad_to_max_length=True,
        truncation=True
    )
    input_ids = tf.convert_to_tensor(tokens['input_ids'])
    token_type_ids = tf.convert_to_tensor(tokens['token_type_ids'])
    attention_mask = tf.convert_to_tensor(tokens['attention_mask'])
    output=mdl(input_ids=input_ids,token_type_ids=token_type_ids,attention_mask=attention_mask)
    o=tf.nn.softmax(output.logits).numpy()
else:
    import torch
    encoded_input = tokenizer(sentences,
    padding="longest",
    pad_to_max_length=True,
    truncation=True, return_tensors='pt')
    # Compute token embeddings
    with torch.no_grad():
        output = mdl(**encoded_input)
    o=torch.nn.functional.softmax(output.logits,dim=1).numpy()
labelId=np.argmax(o,axis=1)
scores=np.max(o,axis=1)
if framework=="tf":
    prediction=[mdl.get_config()["id2label"][idx] for idx in labelId]
else:
    prediction=[mdl.config.id2label[idx] for idx in labelId]
print("Predicted labels: "+str(prediction))
print("Predicted scores: "+str(scores))
