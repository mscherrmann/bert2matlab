# -*- coding: utf-8 -*-

#%% Get Model
import ktrain
from helperFunctions import saveBertWeights
lan="German" # "German", "English"
if lan=="German":
    predictor = ktrain.load_predictor("D:\\Ad_Hoc_Pipeline\\BertMultilabel\\Models\\mymodel24") # German
else:
    predictor = ktrain.load_predictor("D:\\Ad_Hoc_Pipeline\\BertMultilabel\\ModelsEN\\mymodel34") # English
    
# Get tokenizer
tokenizer=predictor.preproc.get_tokenizer()
# Get model
mdl=predictor.model # Get model
if lan=="English":
    testSentence=["EBIT increased about more than 10 %","Mr. Mueller is retiring as an executive director of the Company."];
else:
    testSentence= ["EBIT steigt um mehr als 10 %","Herr Müller scheidet als geschäftsführender Direktor der Gesellschaft aus."]
print(predictor.predict(testSentence))