# -*- coding: utf-8 -*-
"""
Created on Wed Feb 22 13:43:09 2023

@author: scherrmann
"""
from helperFunctions import modelToMatlab
#%% Export BERT based huggingface models from tensorflow (tf) or pytorch (pt).
#
# Already tested on following models:
#
#   Standard BERT (downstreamTask=None):
#   - "bert-base-german-cased" (tf + pt) (German)
#   - "deepset/gbert-base"  (tf + pt) (German)
#   - "nlpaueb/sec-bert-base" (tf + pt) (English)
#   - "nlpaueb/sec-bert-num" (tf + pt) (English)
#   - "nlpaueb/sec-bert-shape" (tf + pt) (English)
#   - "nlpaueb/legal-bert-base-uncased" (tf + pt) (English)
#   - "dmis-lab/biobert-base-cased-v1.2" (pt) (English)
#
#   Sentence Transformers (downstreamTask=None):
#   - "sentence-transformers/all-mpnet-base-v2" (pt) (English)
#   - "sentence-transformers/multi-qa-mpnet-base-dot-v1" (pt) (English)
#
#   BERT for Token Classification (downstreamTask="token-classification"):
#   - "philschmid/gbert-base-germaner" (tf) (German)
#   - "tner/bert-base-tweetner7-2020" (pt) (English)
#
#   BERT for Sequence Classification (downstreamTask="text-classification"):
#   - "nickmuchi/sec-bert-finetuned-finance-classification" (pt) (English)
#   - "oliverguhr/german-sentiment-bert" (tf + pt) (German)
#
#   BERT for Question Answering (downstreamTask="question-answering")
#   - "Q:\Forschung\AA_TextanalysisTools\GermanFinBERT\FinetuneModels\GermanFinBERT\german-fin-gbert-optimized-3-fp-512-small-lr-ba10400\AdhocQuad\seed_3" (pt) (German)

mdlStr= "philschmid/gbert-base-germaner"
downstreamTask="token-classification"# None (Plain Bert Model), "token-classification" (e.g. NER-Tasks), "text-classification" (e.g. Sentiment prediction), "question-answering" (e.g. SQUAD)
framework="tf" # "pt" (PyTorch), "tf" (Tensorflow)
tokenizerStr = None # None, "deepset/gbert-base" , "bert-base-german-cased"
modelToMatlab(mdlStr,downstreamTask,framework,tokenizerStr)  
