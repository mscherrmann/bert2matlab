%% Decide on model
% Possible models until now:
%
% English:
%  - "tner/bert-base-tweetner7-2020" (pt) 
%
% German:
%  - "philschmid/gbert-base-germaner" (tf) (https://www.philschmid.de/huggingface-transformers-keras-tf)
%
% ---------------------------------------------------------------------
% Note: The code is provided solely for illustrative purposes. We can
% neither guarantee that it works nor that it's free of errors, and do not take on any liability. 
% The code is licensed under the BSD License.
% ---------------------------------------------------------------------
% Moritz Scherrmann, LMU Munich, last chage: Feb 23, 2023
% ---------------------------------------------------------------------


modelStr="tner/bert-base-tweetner7-2020";
framework="pt";
language="English"; % "German", "English" (Depending on model)
%% Load Bert model & tokenizer
modelPath="..\Models"; % Adjust to your machine
pathVocab=modelPath+"\"+framework+"\"+modelStr+"\vocab.txt";
pathBertParams=modelPath+"\"+framework+"\"+modelStr+"\matlab_bert_params.mat";
bertModel=readBertFromPython(pathBertParams,pathVocab);
tokenizer = bertModel.Tokenizer;

%% Give some random test sentences
if language=="English"
    sentences= ["Get the all-analog Classic Vinyl Edition of `Takin' Off` Album from {@herbiehancock@} via {@bluenoterecords@} link below: {{URL}}"];
else
    sentences=["Volkswagen ist die Kernmarke der Volkswagen AG."];
end
%% Tokenize sentences
tokens = encode(tokenizer,sentences);

%% Model to GPU
% To speed up feature extraction. Convert the BERT model weights to
% gpuArray if a GPU is available.
if canUseGPU
   bertModel.Parameters.Weights = dlupdate(@gpuArray,bertModel.Parameters.Weights);
end
%% Create Mini Batch Queue
% Create a mini-batch queue for the training data. Specify a mini-batch
% size of 32 and preprocess the mini-batches using the
% |preprocessPredictors| function, listed at the end of the example
miniBatchSize = 64;
paddingValue = bertModel.Tokenizer.PaddingCode;
maxSequenceLength = bertModel.Parameters.Hyperparameters.NumContext;
dsXTest = arrayDatastore(tokens,"OutputType","same");

% Create a mini-batch queue for the test data
mbqTest = minibatchqueue(dsXTest,1,...
    "MiniBatchSize",miniBatchSize, ...
    "MiniBatchFcn",@(X) preprocessPredictors(X,paddingValue,maxSequenceLength,tokenizer.SeparatorCode));
%% Forward BERT
% Convert the test sentences (sequences of BERT model token)s to a
% |N|-by-|embeddingDimension| array of feature vectors, where |N| is the
% number of test sentences and |embeddingDimension| is the dimension
% of the BERT embedding.

featuresTest = [];
reset(mbqTest);
outputFormat="All";
while hasdata(mbqTest)
    X = next(mbqTest);
    features = bertEmbed(X,bertModel.Parameters, ...
        'OutputFormat',outputFormat, ...
        "padCode",tokenizer.PaddingCode, ...
        "sepCode",tokenizer.SeparatorCode, ...
        "isMPNet",false);
    featuresTest = [featuresTest features];
end

%% Apply classification layer of NER Model
prediction=softmax(dlmtimes(bertModel.Parameters.Weights.tokenclassifier.kernel,featuresTest) + bertModel.Parameters.Weights.tokenclassifier.bias,'DataFormat','CTB');
prediction=extractdata(gather(prediction));
[maxVals,maxIds]=max(prediction,[],1);
maxVals=squeeze(maxVals);
maxIds=squeeze(maxIds);
entities=bertModel.Parameters.Hyperparameters.TokenEntities;
maxInputLength=max(cellfun(@length,tokens));
tokensAct=tokenizer.FullTokenizer.decode(tokens{:})';
if length(tokensAct)<maxInputLength
    tokensAct=[tokensAct;repmat("PAD",maxInputLength-length(tokensAct),1)];
end
entitiesAct=entities(maxIds);
tab=array2table([tokensAct,entitiesAct,maxVals'],"VariableNames",["Token","Entity","Score"]);
disp(tab)

