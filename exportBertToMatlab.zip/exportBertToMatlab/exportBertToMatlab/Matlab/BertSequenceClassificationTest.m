%% Decide on model
% Tested models until now:
%
% English:
%  - "nickmuchi/sec-bert-finetuned-finance-classification" (pt) 
%
% German:
%  - "oliverguhr/german-sentiment-bert" (tf + pt)
% ---------------------------------------------------------------------
% Note: The code is provided solely for illustrative purposes. We can
% neither guarantee that it works nor that it's free of errors, and do not take on any liability. 
% The code is licensed under the BSD License.
% ---------------------------------------------------------------------
% Moritz Scherrmann, LMU Munich, last chage: Feb 23, 2023
% ---------------------------------------------------------------------

      
modelStr="nickmuchi/sec-bert-finetuned-finance-classification";
framework="pt";
language="English"; % "German", "English" (Depending on model)
%% Load Bert model & tokenizer
modelPath="..\Models"; % Adjust to your machine
pathVocab=modelPath+"\"+framework+"\"+modelStr+"\vocab.txt";
pathBertParams=modelPath+"\"+framework+"\"+modelStr+"\matlab_bert_params.mat";
bertModel=readBertFromPython(pathBertParams,pathVocab);
tokenizer = bertModel.Tokenizer;

%% Give some random test sentences
if language=="English"
    sentences= ["The USD rallied by 10% last night";...
                "Covid-19 cases have been increasing over the past few months impacting earnings for global firms";...
                "Dividend maintained at CHF 4.00"];
else
    sentences=["Ich bin sehr glücklich.";...
            "Ich bin sehr traurig.";...
            "Eine Zange ist ein Werkzeug"];
end
%% Tokenize sentences
tokens = encode(tokenizer,sentences);


%% Model to GPU
% To speed up feature extraction. Convert the BERT model weights to
% gpuArray if a GPU is available.
if canUseGPU
   bertModel.Parameters.Weights = dlupdate(@gpuArray,bertModel.Parameters.Weights);
end
%% Create Mini Batch Queue
% Create a mini-batch queue for the training data. Specify a mini-batch
% size of 32 and preprocess the mini-batches using the
% |preprocessPredictors| function, listed at the end of the example
miniBatchSize = 64;
paddingValue = bertModel.Tokenizer.PaddingCode;
maxSequenceLength = bertModel.Parameters.Hyperparameters.NumContext;
dsXTest = arrayDatastore(tokens,"OutputType","same");

% Create a mini-batch queue for the test data
mbqTest = minibatchqueue(dsXTest,1,...
    "MiniBatchSize",miniBatchSize, ...
    "MiniBatchFcn",@(X) preprocessPredictors(X,paddingValue,maxSequenceLength,tokenizer.SeparatorCode));
%% Forward BERT
% Convert the test sentences (sequences of BERT model token)s to a
% |N|-by-|embeddingDimension| array of feature vectors, where |N| is the
% number of test sentences and |embeddingDimension| is the dimension
% of the BERT embedding.

featuresTest = [];
reset(mbqTest);
outputFormat="All";
while hasdata(mbqTest)
    X = next(mbqTest);
    features = bertEmbed(X,bertModel.Parameters, ...
        'OutputFormat',"CLS", ...
        "padCode",tokenizer.PaddingCode, ...
        "sepCode",tokenizer.SeparatorCode, ...
        "isMPNet",false);
    featuresTest = [featuresTest features];
end

%% Apply classification layer of NER Model
prediction = tanh(dlmtimes(bertModel.Parameters.Weights.pooler.kernel,featuresTest) + bertModel.Parameters.Weights.pooler.bias);
prediction=softmax(dlmtimes(bertModel.Parameters.Weights.sequenceclassifier.kernel,prediction) + bertModel.Parameters.Weights.sequenceclassifier.bias,'DataFormat','CB');
prediction=extractdata(gather(prediction));
[maxVals,maxIds]=max(prediction,[],1);
entities=bertModel.Parameters.Hyperparameters.TextEntities;
pred=entities(maxIds);
disp("Predicted labels: "+string(pred'))
disp("Predicted scores: "+string(maxVals))

