%% Decide on model

% Possible models until now:
%
% English:
% - "nlpaueb/sec-bert-base" (tf + pt)
% - "nlpaueb/sec-bert-num" (tf + pt)
% - "nlpaueb/sec-bert-shape" (tf + pt)
% - "nlpaueb/legal-bert-base-uncased" (tf + pt)
% - "dmis-lab/biobert-base-cased-v1.2" (pt)
%
% German:
% - bert-base-german-cased (pt + tf)
% - deepset\gbert-base (improved version of bert-base-german-cased,
%               https://arxiv.org/pdf/2010.10906.pdf) (pt+tf)

% ---------------------------------------------------------------------
% Note: The code is provided solely for illustrative purposes. We can
% neither guarantee that it works nor that it's free of errors, and do not take on any liability. 
% The code is licensed under the BSD License.
% ---------------------------------------------------------------------
% Moritz Scherrmann, LMU Munich, last chage: Feb 23, 2023
% ---------------------------------------------------------------------

modelStr="nlpaueb/legal-bert-base-uncased";
framework="tf";
%% Load Bert model & tokenizer
modelPath="..\Models"; % Adjust to your machine
pathVocab=modelPath+"\"+framework+"\"+modelStr+"\vocab.txt";
pathBertParams=modelPath+"\"+framework+"\"+modelStr+"\matlab_bert_params.mat";
bertModel=readBertFromPython(pathBertParams,pathVocab);
tokenizer = bertModel.Tokenizer;

%% Give some random test sentences
sentences= ["This is a test sentence.";"This is a further test senctence."];
%% Tokenize sentences
tokens = encode(tokenizer,sentences);

%% Model to GPU
% To speed up feature extraction. Convert the BERT model weights to
% gpuArray if a GPU is available.
if canUseGPU
   bertModel.Parameters.Weights = dlupdate(@gpuArray,bertModel.Parameters.Weights);
end
%% Create Mini Batch Queue
% Create a mini-batch queue for the training data. Specify a mini-batch
% size of 32 and preprocess the mini-batches using the
% |preprocessPredictors| function, listed at the end of the example
miniBatchSize = 64;
paddingValue = bertModel.Tokenizer.PaddingCode;
maxSequenceLength = bertModel.Parameters.Hyperparameters.NumContext;
dsXTest = arrayDatastore(tokens,"OutputType","same");

% Create a mini-batch queue for the test data
mbqTest = minibatchqueue(dsXTest,1,...
    "MiniBatchSize",miniBatchSize, ...
    "MiniBatchFcn",@(X) preprocessPredictors(X,paddingValue,maxSequenceLength,tokenizer.SeparatorCode));
%% Forward BERT
% Convert the test sentences (sequences of BERT model token)s to a
% |N|-by-|embeddingDimension| array of feature vectors, where |N| is the
% number of test sentences and |embeddingDimension| is the dimension
% of the BERT embedding.

featuresTest = [];
reset(mbqTest);
while hasdata(mbqTest)
    X = next(mbqTest);
    features = bertEmbed(X,bertModel.Parameters, ...
        'OutputFormat',"All", ...
        "padCode",tokenizer.PaddingCode, ...
        "sepCode",tokenizer.SeparatorCode, ...
        "isMPNet",false);
    featuresTest = [featuresTest features];
end

% Print 10 first entries of last hidden state of [CLS] tokens
disp(squeeze(featuresTest(1:10,1,:)))
