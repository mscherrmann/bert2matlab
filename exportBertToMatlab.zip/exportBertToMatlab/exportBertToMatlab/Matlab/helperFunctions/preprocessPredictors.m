function X = preprocessPredictors(X,paddingValue,maxSeqLen,SeparatorCode)
% ---------------------------------------------------------------------
% Note: The code is provided solely for illustrative purposes. We can
% neither guarantee that it works nor that it's free of errors, and do not take on any liability. 
% The code is licensed under the BSD License.
% ---------------------------------------------------------------------
% Moritz Scherrmann, LMU Munich, last chage: Feb 23, 2023
% ---------------------------------------------------------------------

X = truncateSequences(X,maxSeqLen,'SeparatorCode',SeparatorCode);
X = padsequences(X,2,"PaddingValue",paddingValue);

end