function Y = bertEmbed(X,parameters,args)
% BERT Embedding Function
% The |bertEmbed| function maps input data to embedding vectors and
% optionally applies dropout using the "DropoutProbability" name-value
% pair.
% ---------------------------------------------------------------------
% Note: The code is provided solely for illustrative purposes. We can
% neither guarantee that it works nor that it's free of errors, and do not take on any liability. 
% The code is licensed under the BSD License.
% ---------------------------------------------------------------------
% Moritz Scherrmann, LMU Munich, last chage: Feb 23, 2023
% ---------------------------------------------------------------------
arguments
    X
    parameters
    args.DropoutProbability = 0
    args.OutputFormat = "All" % "All" means all hidden states of last layer, "CLS"  means only hidden state of first token
    args.padCode = 1
    args.sepCode = 5
    args.isMPNet = false
end

dropoutProbabilitiy = args.DropoutProbability;
outputFormat = args.OutputFormat;

Y = bert.model(X,parameters, ...
    "DropoutProb",dropoutProbabilitiy, ...
    "AttentionDropoutProb",dropoutProbabilitiy, ...
    "PaddingCode",args.padCode, ...
    "SeparatorCode",args.sepCode, ...
    "isMPNet",args.isMPNet);

% To return single feature vectors, return the first element.
if outputFormat=="CLS"
    Y = Y(:,1,:);
    Y = squeeze(Y);
end

end