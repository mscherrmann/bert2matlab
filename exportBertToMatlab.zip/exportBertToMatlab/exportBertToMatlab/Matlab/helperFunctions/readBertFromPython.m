function bertModel=readBertFromPython(pathBertParams,pathVocab)
% Main function of the Import-Toolbox to import BERT model into Matlab
% 
% ---------------------------------------------------------------------
% Note: The code is provided solely for illustrative purposes. We can
% neither guarantee that it works nor that it's free of errors, and do not take on any liability. 
% The code is licensed under the BSD License.
% ---------------------------------------------------------------------
% Moritz Scherrmann, LMU Munich, last chage: Feb 23, 2023
% ---------------------------------------------------------------------

    bertParams=load(pathBertParams);
    bertModel=struct();
    % Construct tokenizer
    if contains(bertParams.Name,"sentence-transformers")
        bertModel.Tokenizer=bert.tokenizer.BERTTokenizer(pathVocab, ...
            'IgnoreCase',bertParams.Hyperparameters__IgnoreCase, ...
            'CLS',"<s>", ...
            "SEP","</s>", ...
            "PAD","<pad>");
    else
        bertModel.Tokenizer=bert.tokenizer.BERTTokenizer(pathVocab, ...
            'IgnoreCase',bertParams.Hyperparameters__IgnoreCase, ...
            'CLS',"[CLS]", ...
            "SEP","[SEP]", ...
            "PAD","[PAD]");
    end
    % Read model name
    bertModel.Name=bertParams.Name;
     % Read model class name
    bertModel.ClassName=bertParams.ClassName;
    % Read hyperparameters
    bertModel.Parameters.Hyperparameters=readBertHyperparameters(bertParams);
    % Read word embedding layers
    bertModel.Parameters.Weights.embeddings=readBertEmbeddingLayer(bertParams);
    % Read Bert encoder layers
    for layerID=1:bertModel.Parameters.Hyperparameters.NumLayers
        bertModel.Parameters.Weights.encoder_layers.("layer_"+string(layerID))=readBertEncoderLayer(bertParams,layerID);
    end
    % Read pooling layer
    bertModel.Parameters.Weights.pooler=readBertPoolingLayer(bertParams);
    % Read classification layer in case there is one
    if contains(bertModel.ClassName,"SequenceClassification")
        bertModel.Parameters.Weights.sequenceclassifier=readBertSequenceClassificationLayer(bertParams);
    elseif contains(bertModel.ClassName,"TokenClassification")
        % Read NER classification layer in case there is one
        bertModel.Parameters.Weights.tokenclassifier=readBertTokenClassificationLayer(bertParams);
    end
    % Read relative attention bias weights
    if contains(bertModel.Name,"mpnet")
        bertModel.Parameters.Weights.sentenceTransformer.encoder__relative_attention_bias__kernel=bertParams.encoder__relative_attention_bias__kernel;
    end


    %% Helper functions
    function mdl=readBertHyperparameters(weights)
        mdl=struct();
        mdl.NumHeads=weights.Hyperparameters__NumHeads;
        mdl.NumLayers= weights.Hyperparameters__NumLayers;
        mdl.NumContext= weights.Hyperparameters__NumContext;
        mdl.HiddenSize=weights.Hyperparameters__HiddenSize;
        if isfield(weights,"Hyperparameters__TokenEntities")
            mdl.TokenEntities=strip(string(weights.Hyperparameters__TokenEntities));
        end
        if isfield(weights,"Hyperparameters__TextEntities")
            mdl.TextEntities=strip(string(weights.Hyperparameters__TextEntities));
        end
    end
    function mdl=readBertEmbeddingLayer(weights)
        mdl=struct();
        mdl.LayerNorm.beta=dlarray(weights.embeddings__LayerNorm__beta');
        mdl.LayerNorm.gamma=dlarray(weights.embeddings__LayerNorm__gamma');
        mdl.position_embeddings=dlarray(weights.embeddings__position_embeddings__embeddings);
        mdl.token_type_embeddings=dlarray(weights.embeddings__token_type_embeddings__embeddings);
        mdl.word_embeddings=dlarray(weights.embeddings__word_embeddings__weight);
    end
    
    function mdl=readBertEncoderLayer(weights,layerNum)
        mdl=struct();
        mdl.attention.LayerNorm.beta=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__output__LayerNorm__beta")');
        mdl.attention.LayerNorm.gamma=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__output__LayerNorm__gamma")');
        mdl.attention.output.bias=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__output__dense__bias")');
        mdl.attention.output.kernel=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__output__dense__kernel"));
        mdl.attention.key.bias=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__key__bias")');
        mdl.attention.key.kernel=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__key__kernel"));
        mdl.attention.query.bias=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__query__bias")');
        mdl.attention.query.kernel=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__query__kernel"));
        mdl.attention.value.bias=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__value__bias")');
        mdl.attention.value.kernel=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__value__kernel"));
        mdl.feedforward.intermediate.bias=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__intermediate__dense__bias")');
        mdl.feedforward.intermediate.kernel=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__intermediate__dense__kernel"));
        mdl.feedforward.LayerNorm.beta=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__output__LayerNorm__beta")');
        mdl.feedforward.LayerNorm.gamma=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__output__LayerNorm__gamma")');
        mdl.feedforward.output.bias=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__output__dense__bias")');
        mdl.feedforward.output.kernel=dlarray(weights.("encoder__layer__"+string(layerNum-1)+"__output__dense__kernel"));
    end
    
    function mdl=readBertPoolingLayer(weights)
        mdl=struct();
        if isfield(weights,"pooler__dense__bias")
            mdl.bias=dlarray(weights.pooler__dense__bias');
            mdl.kernel=dlarray(weights.pooler__dense__kernel);
        else
            mdl.bias=dlarray(zeros(768,1));
            mdl.kernel=dlarray(zeros(768,768));
        end
    end
    
    function mdl=readBertSequenceClassificationLayer(weights)
        mdl=struct();
        mdl.bias=dlarray(weights.sequenceClassifier__bias');
        mdl.kernel=dlarray(weights.sequenceClassifier__kernel);
    end

    function mdl=readBertTokenClassificationLayer(weights)
        mdl=struct();
        mdl.bias=dlarray(weights.tokenClassifier__bias');
        mdl.kernel=dlarray(weights.tokenClassifier__kernel);
    end
end

