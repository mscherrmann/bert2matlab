function paddedArray=addPads(array,maxLen,paddingCode)
% ---------------------------------------------------------------------
% Note: The code is provided solely for illustrative purposes. We can
% neither guarantee that it works nor that it's free of errors, and do not take on any liability. 
% The code is licensed under the BSD License.
% ---------------------------------------------------------------------
% Moritz Scherrmann, LMU Munich, last chage: Feb 23, 2023
% ---------------------------------------------------------------------

    lenArray=length(array);
    if lenArray<maxLen
        paddedArray=[array,ones(1,maxLen-lenArray)*paddingCode];
    else
        paddedArray=array;
    end
end