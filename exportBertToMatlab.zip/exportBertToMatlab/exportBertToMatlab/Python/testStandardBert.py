# -*- coding: utf-8 -*-
"""
Created on Wed Feb 22 13:29:39 2023

@author: scherrmann
"""

from helperFunctions import getModelAndTokenizer

#%% Get Model
#   Standard BERT (downstreamTask=None):
#   - "bert-base-german-cased" (tf + pt)
#   - "deepset/gbert-base"  (tf + pt)
#   - "nlpaueb/sec-bert-base" (tf + pt)
#   - "nlpaueb/sec-bert-num" (tf + pt)
#   - "nlpaueb/sec-bert-shape" (tf + pt)
#   - "nlpaueb/legal-bert-base-uncased" (tf + pt)
#   - "dmis-lab/biobert-base-cased-v1.2" (pt)
mdlStr="nlpaueb/legal-bert-base-uncased"
downstreamTask=None
framework="tf"
[mdl,tokenizer]=getModelAndTokenizer(mdlStr,downstreamTask,framework)


#%% Examples

# Define input
sentences= ["This is a test sentence.","This is a further test senctence."]
# Tokenize
tokens = tokenizer(
    sentences,
    padding="longest",
    pad_to_max_length=True,
    truncation=True
)
# Tokens to tensor
if framework=="tf":
    import tensorflow as tf
    input_ids = tf.convert_to_tensor(tokens['input_ids'])
    token_type_ids = tf.convert_to_tensor(tokens['token_type_ids'])
    attention_mask = tf.convert_to_tensor(tokens['attention_mask'])
    # Forward pass
    output=mdl(input_ids=input_ids,token_type_ids=token_type_ids,attention_mask=attention_mask, training=False)
else:
    import torch
    encoded_input = tokenizer(sentences, padding=True, truncation=True, return_tensors='pt')
    # Compute token embeddings
    with torch.no_grad():
        output = mdl(**encoded_input,output_hidden_states=True)
# Print 10 first entries last hidden state of [CLS] tokens
print(output.last_hidden_state[:,0,:10])
