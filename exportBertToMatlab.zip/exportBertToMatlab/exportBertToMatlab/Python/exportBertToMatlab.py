# -*- coding: utf-8 -*-
"""
Created on Wed Feb 22 13:43:09 2023

@author: scherrmann
"""
from helperFunctions import modelToMatlab
#%% Export BERT based huggingface models from tensorflow (tf) or pytorch (pt).
#
# Already tested on following models:
#
#   Standard BERT (downstreamTask=None):
#   - "bert-base-german-cased" (tf + pt) (German)
#   - "deepset/gbert-base"  (tf + pt) (German)
#   - "nlpaueb/sec-bert-base" (tf + pt) (English)
#   - "nlpaueb/sec-bert-num" (tf + pt) (English)
#   - "nlpaueb/sec-bert-shape" (tf + pt) (English)
#   - "nlpaueb/legal-bert-base-uncased" (tf + pt) (English)
#   - "dmis-lab/biobert-base-cased-v1.2" (pt) (English)
#
#   Sentence Transformers (downstreamTask=None):
#   - "sentence-transformers/all-mpnet-base-v2" (pt) (English)
#   - "sentence-transformers/multi-qa-mpnet-base-dot-v1" (pt) (English)
#
#   BERT for Token Classification (downstreamTask="token-classification"):
#   - "philschmid/gbert-base-germaner" (tf) (German)
#   - "tner/bert-base-tweetner7-2020" (pt) (English)
#
#   BERT for Sequence Classification (downstreamTask="text-classification"):
#   - "nickmuchi/sec-bert-finetuned-finance-classification" (pt) (English)
#   - "oliverguhr/german-sentiment-bert" (tf + pt) (German)
#  Note: 
#  The code is provided solely for illustrative purposes. We can
#  neither guarantee that it works nor that it's free of errors, and do not take on any liability. 
#  The code is licensed under the BSD License.

mdlStr="bert-base-german-cased"
downstreamTask=None# None (Plain Bert Model), "token-classification" (e.g. NER-Tasks), "text-classification" (e.g. Sentiment prediction)
framework="pt" # "pt" (PyTorch), "tf" (Tensorflow)
modelToMatlab(mdlStr,downstreamTask,framework)  
