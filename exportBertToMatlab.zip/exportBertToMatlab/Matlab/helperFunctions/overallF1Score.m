function totalF1=overallF1Score(target,prediction)
    vals=[];
    for col =target.Properties.VariableNames
        vals=[vals;f1Score(target.(string(col)),prediction.(string(col)))];
    end
    vals=[mean(vals);vals];
    totalF1=array2table(vals,"RowNames",["Macro F1",string(target.Properties.VariableNames)]);
end