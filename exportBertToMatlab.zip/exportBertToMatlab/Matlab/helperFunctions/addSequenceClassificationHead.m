function lgraph = addSequenceClassificationHead(lgraph,bertWeights,options)
    arguments
       lgraph
       bertWeights struct
       options.sequenceClassifierWeights struct = struct()
       options.numClasses (1,1) {mustBeNumeric} = nan
    end
    
    sequenceClassifierWeights =options.sequenceClassifierWeights;
    numClasses = options.numClasses;
    if length(fieldnames(sequenceClassifierWeights)) == 0
        % No classification weights given. Check that numClasses given,
        % otherwise throw error
        assert(~isnan(numClasses), "If no classification weights given, you have to provide numClasses")
        % Randomly initialize weights
        sequenceClassifierWeights.kernel = randn(numClasses,bertWeights.Hyperparameters__EmbeddingDimension);
        sequenceClassifierWeights.bias = randn(numClasses,1);
    end
        
    layers = [
        indexing1dLayer(Name="out_pool")
        fullyConnectedLayer(numel(bertWeights.pooler__dense__bias), Name="out_fc1", Weights=bertWeights.pooler__dense__kernel, Bias=bertWeights.pooler__dense__bias')
        tanhLayer(Name="out_tanh")
        fullyConnectedLayer(numel(sequenceClassifierWeights.bias), Name="out_fc2", Weights=sequenceClassifierWeights.kernel, Bias=sequenceClassifierWeights.bias)];
    lgraph = addLayers(lgraph, layers);
    lgraph = connectLayers(lgraph, "enc"+bertWeights.Hyperparameters__NumLayers+"_layernorm2", "out_pool");
end