function [net, tokenizer]=readBertFromMatlab(pathBert,pathVocab)

    net = load(pathBert);
    tokenizer = load(pathVocab);
    
end