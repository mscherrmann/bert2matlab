function mp=meanPooling(token_embeddings,tokens,paddingCode)
    % Compute attention mask
    inputLengths=cellfun(@length,tokens);
    maxSeqLength=max(inputLengths);
    tokens=arrayfun(@(x)addPads(x{1},maxSeqLength,paddingCode), tokens,'UniformOutput',false);
    tokens=cell2mat(tokens);
    attention_mask=tokens~=paddingCode;
    attention_mask=reshape(attention_mask',1,size(tokens,2),size(tokens,1));
    input_mask_expanded=repmat(attention_mask,size(token_embeddings,1),1,1);
    % Calculate mean of of embeddings with attention_mask=1. If no
    % attention at all is paid, we do not divide by 0 but 1e-9
    mp=squeeze(sum(token_embeddings.* input_mask_expanded, 2)) ./ max(squeeze(sum(input_mask_expanded,2)), 1e-9);
end