function f1=f1Score(target,prediction)
    tp=sum(logical(target)&logical(prediction));
    %tn=sum((~logical(target))&(~logical(prediction)));
    fp=sum((~logical(target))&logical(prediction));
    fn=sum(logical(target)&(~logical(prediction)));
    precision=tp/(tp+fp);
    recall=tp/(tp+fn);
    f1=2*(precision*recall)/(precision+recall);
end