function aggData=aggregateToDocumentLevel(input)
    categories=string(input.Properties.VariableNames);
    categories=categories(categories~="Hashs");
    aggData = groupsummary(input,'Hashs','sum');
    aggData= removevars(aggData,{'Hashs','GroupCount'});
    aggData=(aggData{:,:}>0)*1;
    aggData=array2table(aggData);
    aggData.Properties.VariableNames=categories;
end