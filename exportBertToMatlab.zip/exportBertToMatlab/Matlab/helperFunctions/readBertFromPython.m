function [net, tokenizer, additionalInfo]=readBertFromPython(pathBertParams,pathVocab)
    bertModel = struct();
    additionalInfo = struct();
    % Read parameters file
    bertParams=load(pathBertParams);

    % Get hyperparameters
    bertModel.Hyperparameters=readBertHyperparameters(bertParams);

    % Create tokenizer object
    ignoreCase = bertModel.Hyperparameters.IgnoreCase;
    stripAccents = bertModel.Hyperparameters.StripAccents;
    vocab = string(textread(pathVocab, '%s', 'delimiter', '\n'));
    tokenizer=bertTokenizer(vocab,'IgnoreCase',ignoreCase,'StripAccents',stripAccents);
    bertModel.Hyperparameters = rmfield(bertModel.Hyperparameters,"IgnoreCase");
    bertModel.Hyperparameters = rmfield(bertModel.Hyperparameters,"StripAccents");

    % Get word embedding layers
    bertModel.Weights.embeddings=readBertEmbeddingLayer(bertParams);

    % Get Bert encoder layers
    for layerID=1:bertModel.Hyperparameters.NumLayers
        bertModel.Weights.encoder_layers.("layer_"+string(layerID))=readBertEncoderLayer(bertParams,layerID);
    end

    % Read pooling layer
    bertModel.Weights.pooler=readBertPoolingLayer(bertParams,bertModel.Hyperparameters.EmbeddingDimension);

    % Create bert model
    % Buld MpNet if given
    net = textanalytics.internal.bertmodel.buildNetwork(bertModel,"none",[], 0.1,0.1);
    
    % Add classification layer in case there is one
    if contains(bertParams.ClassName,"SequenceClassification")
        lgraph = net.layerGraph();
        sequenceClassifierWeights=readBertSequenceClassificationLayer(bertParams);
        lgraph = addSequenceClassificationHead(lgraph,bertParams,'sequenceClassifierWeights',sequenceClassifierWeights);
        net = dlnetwork(lgraph);
        if isfield(bertParams,"Hyperparameters__TextEntities")
            additionalInfo.TextEntities=strip(string(bertParams.Hyperparameters__TextEntities));
        end
    elseif contains(bertParams.ClassName,"TokenClassification")
        lgraph = net.layerGraph();
        tokenClassifierWeights=readBertTokenClassificationLayer(bertParams);
        lgraph = addTokenClassificationHead(lgraph,bertParams,'tokenClassifierWeights',tokenClassifierWeights);
        net = dlnetwork(lgraph);
        if isfield(bertParams,"Hyperparameters__TokenEntities")
            additionalInfo.TokenEntities=strip(string(bertParams.Hyperparameters__TokenEntities));
        end
    elseif contains(bertParams.ClassName,"QuestionAnswering")
        lgraph = net.layerGraph();
        questionAnsweringWeights=readBertQuestionAnsweringLayer(bertParams);
        lgraph = addQuestionAnsweringHead(lgraph,bertParams,'questionAnsweringWeights',questionAnsweringWeights);
        net = dlnetwork(lgraph);
    end


    %% Helper functions

    function mdl=readBertHyperparameters(weights)
        mdl=struct();
        mdl.NumHeads=weights.Hyperparameters__NumHeads;
        mdl.NumLayers= weights.Hyperparameters__NumLayers;
        mdl.IgnoreCase= weights.Hyperparameters__IgnoreCase;
        mdl.NumContext= weights.Hyperparameters__NumContext;
        mdl.HiddenSize=weights.Hyperparameters__HiddenSize;
        mdl.EmbeddingDimension=weights.Hyperparameters__EmbeddingDimension;
        mdl.StripAccents= weights.Hyperparameters__StripAccents;
        mdl.NormEps= weights.Hyperparameters__NormEps;
    end

    function mdl=readBertEmbeddingLayer(weights)
        mdl=struct();
        mdl.LayerNorm.beta=weights.embeddings__LayerNorm__beta';
        mdl.LayerNorm.gamma=weights.embeddings__LayerNorm__gamma';
        mdl.position_embeddings=weights.embeddings__position_embeddings__embeddings;
        mdl.token_type_embeddings=weights.embeddings__token_type_embeddings__embeddings;
        mdl.word_embeddings=weights.embeddings__word_embeddings__weight;
    end
    
    function mdl=readBertEncoderLayer(weights,layerNum)
        mdl=struct();
        mdl.attention.LayerNorm.beta=weights.("encoder__layer__"+string(layerNum-1)+"__attention__output__LayerNorm__beta")';
        mdl.attention.LayerNorm.gamma=weights.("encoder__layer__"+string(layerNum-1)+"__attention__output__LayerNorm__gamma")';
        mdl.attention.output.bias=weights.("encoder__layer__"+string(layerNum-1)+"__attention__output__dense__bias")';
        mdl.attention.output.kernel=weights.("encoder__layer__"+string(layerNum-1)+"__attention__output__dense__kernel");
        mdl.attention.key.bias=weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__key__bias")';
        mdl.attention.key.kernel=weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__key__kernel");
        mdl.attention.query.bias=weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__query__bias")';
        mdl.attention.query.kernel=weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__query__kernel");
        mdl.attention.value.bias=weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__value__bias")';
        mdl.attention.value.kernel=weights.("encoder__layer__"+string(layerNum-1)+"__attention__self__value__kernel");
        mdl.feedforward.intermediate.bias=weights.("encoder__layer__"+string(layerNum-1)+"__intermediate__dense__bias")';
        mdl.feedforward.intermediate.kernel=weights.("encoder__layer__"+string(layerNum-1)+"__intermediate__dense__kernel");
        mdl.feedforward.LayerNorm.beta=weights.("encoder__layer__"+string(layerNum-1)+"__output__LayerNorm__beta")';
        mdl.feedforward.LayerNorm.gamma=weights.("encoder__layer__"+string(layerNum-1)+"__output__LayerNorm__gamma")';
        mdl.feedforward.output.bias=weights.("encoder__layer__"+string(layerNum-1)+"__output__dense__bias")';
        mdl.feedforward.output.kernel=weights.("encoder__layer__"+string(layerNum-1)+"__output__dense__kernel");
    end
    
    function mdl=readBertPoolingLayer(weights, embeddingDimension)
        mdl=struct();
        if isfield(weights,"pooler__dense__bias")
            mdl.bias=weights.pooler__dense__bias';
            mdl.kernel=weights.pooler__dense__kernel;
        else
            mdl.bias=zeros(embeddingDimension,1);
            mdl.kernel=zeros(embeddingDimension,embeddingDimension);
        end
    end
    
    function mdl=readBertSequenceClassificationLayer(weights)
        mdl=struct();
        mdl.bias=weights.sequenceClassifier__bias';
        mdl.kernel=weights.sequenceClassifier__kernel;
    end

    function mdl=readBertTokenClassificationLayer(weights)
        mdl=struct();
        mdl.bias=weights.tokenClassifier__bias';
        mdl.kernel=weights.tokenClassifier__kernel;
    end

    function mdl=readBertQuestionAnsweringLayer(weights)
        mdl=struct();
        mdl.bias=weights.qa_outputs__bias';
        mdl.kernel=weights.qa_outputs__kernel;
    end

end

