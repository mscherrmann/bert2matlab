function lgraph = addTokenClassificationHead(lgraph,bertWeights,options)
    arguments
       lgraph
       bertWeights struct
       options.tokenClassifierWeights struct = struct()
       options.numClasses (1,1) {mustBeNumeric} = nan
    end
    tokenClassifierWeights =options.tokenClassifierWeights;
    numClasses = options.numClasses;

    if length(fieldnames(tokenClassifierWeights)) == 0
        % No classification weights given. Check that numClasses given,
        % otherwise throw error
        assert(~isnan(numClasses), "If no classification weights given, you have to provide numClasses")
        % Randomly initialize weights
        tokenClassifierWeights.kernel = randn(numClasses,bertWeights.Hyperparameters__EmbeddingDimension);
        tokenClassifierWeights.bias = randn(numClasses,1);
    end

    
    layers = [            
        fullyConnectedLayer(numel(tokenClassifierWeights.bias), Name="out_fc1", Weights=tokenClassifierWeights.kernel, Bias=tokenClassifierWeights.bias)
        softmaxLayer(Name="out_softmax")];
    lgraph = addLayers(lgraph, layers);
    lgraph = connectLayers(lgraph, "enc"+bertWeights.Hyperparameters__NumLayers+"_layernorm2", "out_fc1");
    end