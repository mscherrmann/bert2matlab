function [inputIds,segmentIds] = fastBertTokens(Sentences,tokenizer,opts)
% Function to use BERT tokenizer in parallel
arguments
    Sentences string
    tokenizer 
    opts.batchSize double=750;
    opts.numPool = 8;
end

% determine batch size
batchSize = opts.batchSize;
numBatch=ceil(size(Sentences,1)/batchSize);

% set number of processors to be used in parallel
p = gcp('nocreate'); % If no pool, do not create new one.
if isempty(p)
    parpool(opts.numPool);
else
    delete(p);
    parpool(min(numBatch,opts.numPool));
end


% tokenize in parallel
inputIdsPartData=cell(numBatch,1);
segmentIdsPartData=cell(numBatch,1);
parfor ii=1:numBatch
    batchRange = (ii-1) * batchSize + 1 : min(ii * batchSize, size(Sentences,1));
    [inputIds, segmentIds]=encode(tokenizer,Sentences(batchRange));
    inputIdsPartData{ii,1} = inputIds;
    segmentIdsPartData{ii,1} = segmentIds;
    
end
inputIds=vertcat(inputIdsPartData{:});
segmentIds=vertcat(segmentIdsPartData{:});
end
