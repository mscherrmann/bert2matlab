function [tokenized_examples,labelsStart,labelsEnd] = prepare_train_features(context,question,answer, tokenizer, max_length)

     % Some of the questions have lots of whitespace on the left, which is not useful and will make the
    % truncation of the context fail (the tokenized question will take a lots of space). So we remove that
    % left whitespace
    question = strtrim(question);

    % Tokenize our examples with truncation and maybe padding.
    [inputIds, segmentIds] = encode(tokenizer, question, context);
    tokenized_examples = preprocessPredictors(tokenized_examples,tokenizer.PaddingCode,max_length,tokenizer.SeparatorCode);
    offsets = get_offset_mappings(question,context, inputIds,tokenizer);
    %tokenized_examples = squeeze(tokenized_examples);

    % Create labels

    labelsStart = zeros(size(tokenized_examples,2),size(tokenized_examples,3));
    labelsEnd = zeros(size(tokenized_examples,2),size(tokenized_examples,3));
    for idx = 1:length(context)
        % Get Offset
        offsetAct = offsets{idx};
        % Set offset idx of question to zero
        specialTokensMask = offsetAct(:,1)==0;
        specialTokensIdx=find(specialTokensMask);
        offsetAct(specialTokensIdx(1):specialTokensIdx(2),:) = 0;
        % Get answer
        answerStartAct = answer{idx,2}+1;
        answerAct = answer{idx,3};
        answerEndAct = answerStartAct + strlength(answerAct)-1;
        % Check if answer is not contained in context (answer start not
        % corret!)
        if all(offsetAct(:,2)<answerEndAct)
            labelsStart(1,idx) = 1;
            labelsEnd(1,idx) = 1;
        else
            labelsStart(offsetAct(:,1)==answerStartAct,idx) = 1;
            labelsEnd(offsetAct(:,2)==answerEndAct,idx) = 1;
        end
    end
end
