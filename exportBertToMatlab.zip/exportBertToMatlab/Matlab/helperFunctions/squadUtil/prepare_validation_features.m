function [inputIds, mask, segmentIds, answer] = prepare_validation_features(context,question,answer, tokenizer, max_length)
    % Some of the questions have lots of whitespace on the left, which is not useful and will make the
    % truncation of the context fail (the tokenized question will take a lots of space). So we remove that
    % left whitespace
    question = strtrim(question);

    % Tokenize our examples with truncation and maybe padding.
    if isa(context, "tokenizedDocument")
        [inputIds, segmentIds] = encodeTokens(tokenizer,question, context);
    else
        [inputIds, segmentIds] = encode(tokenizer,question, context);
    end   

    endOfSentenceCode = tokenizer.SeparatorCode;
    paddingCode = tokenizer.PaddingCode;

    [inputIds, segmentIds] = textanalytics.internal.bertmodel.truncateSequences(inputIds, segmentIds, endOfSentenceCode, max_length);
    [inputIds, mask] = padsequences(inputIds, 2,"PaddingValue",paddingCode,'Length',max_length);
    segmentIds = padsequences(segmentIds, 2,"PaddingValue",paddingCode,'Length',max_length);
    
    for idx = 1:length(context)
        truncatedExample = decode(tokenizer,inputIds(1,:,idx));
        truncatedExample= replace(truncatedExample," ","");
        if ~contains(truncatedExample, replace(answer(idx)," ",""))
            answer(idx)="[CLS]";
        end
    end
end
