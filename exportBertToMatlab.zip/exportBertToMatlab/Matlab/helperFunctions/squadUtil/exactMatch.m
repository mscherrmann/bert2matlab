function exactMatchScore = exactMatch(labelsStart, labelsEnd, predictionStart, predictionEnd)
% Inputs are given as matrices, where each column represents one
% observation. One observation is a logical array with the number of
% elements equal to the specified maximal sequence length.
    exactMatchMask = all(labelsStart==predictionStart,1) & all(labelsEnd==predictionEnd,1);
    exactMatchScore = sum(exactMatchMask)/length(exactMatchMask);
end
    
