function predictedAnswerIndices = get_model_answer(all_start_logits,all_end_logits, n_best_size, max_answer_length)
    predictedAnswerIndices = ones(size(all_start_logits,2),2);
    % Loop over all examples
    for example_index = 1:size(all_start_logits,2)
        start_logits = all_start_logits(:,example_index);
        end_logits = all_end_logits(:,example_index);

        [~, sorted_start_indices] = sort(start_logits, 'descend');
        [~, sorted_end_indices] = sort(end_logits, 'descend');
        predictedStartIndex=1;
        predictedEndIndex=1;
        maxScore = (max(abs(start_logits))+max(abs(end_logits)))*(-1);
        for start_index = sorted_start_indices(1:n_best_size)'
            for end_index = sorted_end_indices(1:n_best_size)'
                % Check if valid answer
                if end_index < start_index || end_index - start_index + 1 > max_answer_length
                    continue
                end
                % No [CLS] token
                if start_index == 1 || end_index == 1
                    continue
                end
                % Check if new score is higher than actual max score
                newScore = start_logits(start_index) + end_logits(end_index);
                if newScore > maxScore
                    maxScore = newScore;
                    predictedStartIndex = start_index;
                    predictedEndIndex = end_index;
                end
            end
        end
        predictedAnswerIndices(example_index,1)=predictedStartIndex;
        predictedAnswerIndices(example_index,2)=predictedEndIndex;
    end
end