function f1Score = f1_qa(labelsStart, labelsEnd, predictionsStart, predictionsEnd)
    % Inputs are given as matrices, where each column represents one
    % observation. One observation is a logical array with the number of
    % elements equal to the specified maximal sequence length.
    labels = labelsStart | labelsEnd;
    labelsNew=(cumsum(labels,1)==1) | labels;
    labelsNew(:,sum(labels,1)==1) = labels(:,sum(labels,1)==1);
    predictions = predictionsStart | predictionsEnd;
    predictionsNew=(cumsum(predictions,1)==1) | predictions;
    predictionsNew(:,sum(predictions,1)==1) = predictions(:,sum(predictions,1)==1);

    %  Calculate f1
    tp = sum(predictionsNew & labelsNew,1);
    fp = sum(predictionsNew & ~labelsNew,1);
    fn = sum(~predictionsNew & labelsNew,1);
    
    f1Score = mean((2.*tp)./(2*tp+fp+fn));

end
    
