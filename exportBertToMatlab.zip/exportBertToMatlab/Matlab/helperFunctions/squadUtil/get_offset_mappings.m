function offsets = get_offset_mappings(questions,contexts,tokens,tokenizer)
    offsets = cell(length(questions),1);
    for idx=1:length(questions)
        offsetAct =  get_offset_mapping(questions{idx},contexts{idx},tokens(1,:,idx),tokenizer);
        offsets{idx} = offsetAct;
    end
end


