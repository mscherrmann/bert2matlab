function predictions = postprocess_qa_predictions(tokens, raw_predictions, tokenizer, n_best_size, max_answer_length)
    raw_predictions = extractdata(gather(raw_predictions));
    raw_predictions = permute(raw_predictions,[1,3,2]);
    % Unpack raw_predictions (2 x seqlength x nObs)
    all_start_logits = squeeze(raw_predictions(1,:,:));
    all_end_logits = squeeze(raw_predictions(2,:,:));


    % Get predicted indices
    predictedAnswerIndices = get_model_answer(all_start_logits,all_end_logits, n_best_size, max_answer_length);

    % Create a cell array to store predictions
    predictions = strings(1, size(tokens,3));

    % Loop over all examples
    for example_index = 1:size(tokens,3)
        start_index = predictedAnswerIndices(example_index,1);
        end_index = predictedAnswerIndices(example_index,2);
        predictedAnswerAct = decode(tokenizer,tokens(1,start_index:end_index,example_index));
        predictedAnswerAct = replace(predictedAnswerAct," ##","");
        predictions(example_index) = predictedAnswerAct;
    end
end
