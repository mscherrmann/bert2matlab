function offsets = get_offset_mapping(question,context,tokens,tokenizer)
    % Prepare text
    text = char(question + context);
    textLen = length(text);
    % Decode tokens
    tokens = decode(tokenizer,tokens);
    tokens = split(tokens," ");
    % Token
    tokenAct = tokens(1);
    tokenAct = replace(tokenAct,"##","");
    tokenAct = lower(tokenAct);
    tokenLengthAct = strlength(tokenAct);
    % Ids
    tokenId = 1;
    inputTextId = 1;
    charId = 1;
    % Predefine offsets
    offsets = cell(length(tokens),1);
    % Loop
    while inputTextId<=textLen
        if ismember(tokenAct,["[cls]","[sep]","[pad]"])
            offsets{tokenId}=[0,0];
            tokenId = tokenId + 1;
            if tokenId > length(tokens)
                break
            end
            tokenAct = tokens(tokenId);
            tokenAct = replace(tokenAct,"##","");
            tokenAct = lower(tokenAct);
            tokenLengthAct = strlength(tokenAct);
            charId=1;
            continue
        end
        if charId-tokenLengthAct<0
            charId = charId + tokenLengthAct-1;
            inputTextId = inputTextId +tokenLengthAct-1;
        end
        textAct = lower(string(text(inputTextId-tokenLengthAct+1:inputTextId)));
        if textAct == tokenAct
            offsets{tokenId}=[charId-tokenLengthAct+1,charId];
            tokenId = tokenId + 1;
            if tokenId > length(tokens)
                break
            end
            tokenAct = tokens(tokenId);
            tokenAct = replace(tokenAct,"##","");
            tokenAct = lower(tokenAct);
            tokenLengthAct = strlength(tokenAct);
        end
        charId = charId + 1;
        inputTextId = inputTextId +1;
    end
    offsets(tokenId:end)={[0,0]};
    offsets = cell2mat(offsets);
end