function paddedArray=addPadLabelsNer(array,maxLen,paddingCode)
% Add "O" for padding values to fill sequency of labels to maxLen.
% If array len>maxLen, trancuncate labels
    lenArray=length(array);
    if lenArray<maxLen
        paddedArray=[array,repmat("O",1,maxLen-lenArray)];
    elseif lenArray>maxLen
        paddedArray=[array(1:maxLen-1),array(end)];
    else
        paddedArray=array;
    end
end