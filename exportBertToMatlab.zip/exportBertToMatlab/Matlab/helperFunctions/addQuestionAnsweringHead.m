function lgraph = addQuestionAnsweringHead(lgraph,bertWeights,options)
    arguments
       lgraph
       bertWeights struct
       options.questionAnsweringWeights struct = struct()
    end

    questionAnsweringWeights =options.questionAnsweringWeights;

    if length(fieldnames(questionAnsweringWeights)) == 0
        % Randomly initialize weights
        questionAnsweringWeights.kernel = randn(2,bertWeights.Hyperparameters__EmbeddingDimension);
        questionAnsweringWeights.bias = randn(2,1);
    end

    
    layers = [fullyConnectedLayer(numel(questionAnsweringWeights.bias), Name="out_fc1", Weights=questionAnsweringWeights.kernel, Bias=questionAnsweringWeights.bias)];
    lgraph = addLayers(lgraph, layers);
    lgraph = connectLayers(lgraph, "enc"+bertWeights.Hyperparameters__NumLayers+"_layernorm2", "out_fc1");
end