function paddedArray=addPads(array,maxLen,paddingCode)
    lenArray=length(array);
    if lenArray<maxLen
        paddedArray=[array,ones(1,maxLen-lenArray)*paddingCode];
    else
        paddedArray=array;
    end
end