%% Decide on model

% Possible models until now:
%
% English:
%  - "tner/bert-base-tweetner7-2020" (pt) 
%
% German:
%  - "philschmid/gbert-base-germaner" (tf) (https://www.philschmid.de/huggingface-transformers-keras-tf)
      
modelStr="philschmid/gbert-base-germaner";
framework="tf";
language="German"; % "German", "English" (Depending on model)
%% Load Bert model & tokenizer
modelPath="..\..\Models"; % Adjust to your machine
pathVocab=modelPath+"\"+framework+"\"+modelStr+"\vocab.txt";
pathBertParams=modelPath+"\"+framework+"\"+modelStr+"\matlab_bert_params.mat";
[bertModel, tokenizer, additionalInfo]=readBertFromPython(pathBertParams,pathVocab);
entities=additionalInfo.TokenEntities;
%% Give some random test sentences
if language=="English"
    sentences= ["Get the all-analog Classic Vinyl Edition of `Takin' Off` Album from {@herbiehancock@} via {@bluenoterecords@} link below: {{URL}}";...
        "I like the new song of {@bobsinclair@}, it is so funky."];
else
    sentences=["Volkswagen ist die Kernmarke der Volkswagen AG.";"China hat mehr Einwohner als Japan."];
end
%% Create Mini Batch Queue
miniBatchSize = 64;
[mbqTest, tokens] =  createMbqForPrediction(tokenizer, sentences, miniBatchSize);

%% Model to GPU
% To speed up feature extraction. Convert the BERT model weights to
% gpuArray if a GPU is available.
if canUseGPU
   bertModel = dlupdate(@gpuArray, bertModel);
end
%% Forward BERT
% Convert the test sentences (sequences of BERT model token)s to a
% |N|-by-|embeddingDimension| array of feature vectors, where |N| is the
% number of test sentences and |embeddingDimension| is the dimension
% of the BERT embedding.
maxInputLength=min(tokenizer.ContextSize,max(cellfun(@length,tokens)));
predictions = categorical(repmat("O",numel(sentences),maxInputLength),entities);
reset(mbqTest);
idx = 1;
while hasdata(mbqTest)
    [inputIds, attentionMask, segmentIds] = next(mbqTest);
    Y = predict(bertModel,inputIds,attentionMask,segmentIds);
    YPred = onehotdecode(Y,entities,1);
    offset = size(Y,2);
    predictions(idx:idx+offset-1,:) = YPred(1,:,:);
    idx = idx + offset;
end

subwordTokenizeId = @(x)  tokenizer.subwordTokenize(x);
subwords = arrayfun(@(x) subwordTokenizeId(x),sentences);
results = struct();
for subWordsIdx = 1:length(subwords)
    subwordsAct = subwords{subWordsIdx}';
    if numel(subwordsAct)<maxInputLength
        subwordsAct=[subwordsAct;repmat("PAD",maxInputLength-numel(subwordsAct),1)];
    end
    tab=array2table([subwordsAct,string(predictions(subWordsIdx,:)')],"VariableNames",["Token","Entity"]);
    results.("Example_"+string(subWordsIdx)) = tab;
end
%% Helper functions

function [mbq,inputIds] = createMbqForPrediction(tokenizer, text, miniBatchSize)

    if isa(text, "tokenizedDocument")
        [inputIds, segmentIds] = encodeTokens(tokenizer, text);
    else
        [inputIds, segmentIds] = encode(tokenizer, text);
    end   

    endOfSentenceCode = tokenizer.SeparatorCode;
    paddingCode = tokenizer.PaddingCode;

    maxSeqLength = tokenizer.ContextSize;

    inputIdsDs = arrayDatastore(inputIds, OutputType="same"); 
    segmentIdsDs = arrayDatastore(segmentIds, OutputType="same"); 
    combinedDs = combine(inputIdsDs, segmentIdsDs);  

    mbq = minibatchqueue(combinedDs,3,... % 3 outputs: inputIds, mask, segmentIds
        MiniBatchSize=miniBatchSize, ...
        MiniBatchFcn=@(inputIds,segmentIds) textanalytics.internal.bertmodel.preprocessPredictors ...
            (inputIds, ...
             segmentIds, ...
             paddingCode, ...
             endOfSentenceCode, ...
             maxSeqLength), ...
        MiniBatchFormat=["CTB" "CTB" "CTB"]);
                       
end
