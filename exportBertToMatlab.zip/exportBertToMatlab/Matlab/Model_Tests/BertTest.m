%% Decide on model

% Possible models until now:
%
% English:
% - "nlpaueb/sec-bert-base" (tf + pt)
% - "nlpaueb/sec-bert-num" (tf + pt)
% - "nlpaueb/sec-bert-shape" (tf + pt)
% - "nlpaueb/legal-bert-base-uncased" (tf + pt)
% - "dmis-lab/biobert-base-cased-v1.2" (pt)
%
% German:
% - bert-base-german-cased (pt + tf)
% - deepset\gbert-base (improved version of bert-base-german-cased,
%               https://arxiv.org/pdf/2010.10906.pdf) (pt+tf)
modelStr="nlpaueb/legal-bert-base-uncased";
framework="tf";
%% Load Bert model & tokenizer
modelPath="..\..\Models"; % Adjust to your machine
pathVocab=modelPath+"\"+framework+"\"+modelStr+"\vocab.txt";
pathBertParams=modelPath+"\"+framework+"\"+modelStr+"\matlab_bert_params.mat";
[bertModel, tokenizer, additionalInfo]=readBertFromPython(pathBertParams,pathVocab);

%% Give some random test sentences
sentences= ["This is a test sentence.";"This is a further test sentence."];
%% Create Mini Batch Queue
miniBatchSize = 64;
mbqTest =  createMbqForPrediction(tokenizer, sentences, miniBatchSize);
%% Model to GPU
% To speed up feature extraction. Convert the BERT model weights to
% gpuArray if a GPU is available.
if canUseGPU
   bertModel = dlupdate(@gpuArray, bertModel);
end

%% Forward BERT
% Convert the test sentences (sequences of BERT model token)s to a
% |N|-by-|embeddingDimension| array of feature vectors, where |N| is the
% number of test sentences and |embeddingDimension| is the dimension
% of the BERT embedding.

featuresTest = [];
reset(mbqTest);
while hasdata(mbqTest)
    [inputIds, attentionMask, segmentIds] = next(mbqTest);
    Y = predict(bertModel,inputIds,attentionMask,segmentIds);
    Y = permute(extractdata(gather(Y)),[1,3,2]);
    featuresTest = [featuresTest Y];
end

% Print 10 first entries of last hidden state of [CLS] tokens
disp(squeeze(featuresTest(1:10,1,:)))

%% Helper functions
function mbq = createMbqForPrediction(tokenizer, text, miniBatchSize)

    if isa(text, "tokenizedDocument")
        [inputIds, segmentIds] = encodeTokens(tokenizer, text);
    else
        [inputIds, segmentIds] = encode(tokenizer, text);
    end   

    endOfSentenceCode = tokenizer.SeparatorCode;
    paddingCode = tokenizer.PaddingCode;

    maxSeqLength = tokenizer.ContextSize;

    inputIdsDs = arrayDatastore(inputIds, OutputType="same"); 
    segmentIdsDs = arrayDatastore(segmentIds, OutputType="same"); 
    combinedDs = combine(inputIdsDs, segmentIdsDs);  

    mbq = minibatchqueue(combinedDs,3,... % 3 outputs: inputIds, mask, segmentIds
        MiniBatchSize=miniBatchSize, ...
        MiniBatchFcn=@(inputIds,segmentIds) textanalytics.internal.bertmodel.preprocessPredictors ...
            (inputIds, ...
             segmentIds, ...
             paddingCode, ...
             endOfSentenceCode, ...
             maxSeqLength), ...
        MiniBatchFormat=["CTB" "CTB" "CTB"]);
                       
end

