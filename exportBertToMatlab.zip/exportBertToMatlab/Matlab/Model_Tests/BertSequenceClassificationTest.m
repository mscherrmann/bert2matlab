%% Decide on model

% Possible models until now:
%
% English:
%  - "nickmuchi/sec-bert-finetuned-finance-classification" (pt) 
%
% German:
%  - "oliverguhr/german-sentiment-bert" (tf + pt)
      
modelStr="oliverguhr/german-sentiment-bert";
framework="pt";
language="German"; % "German", "English" (Depending on model)
%% Load Bert model & tokenizer
modelPath="..\..\Models"; % Adjust to your machine
pathVocab=modelPath+"\"+framework+"\"+modelStr+"\vocab.txt";
pathBertParams=modelPath+"\"+framework+"\"+modelStr+"\matlab_bert_params.mat";
[bertModel, tokenizer, additionalInfo]=readBertFromPython(pathBertParams,pathVocab);
classes = additionalInfo.TextEntities;
%% Give some random test sentences
if language=="English"
    sentences= ["The USD rallied by 10% last night";...
                "Covid-19 cases have been increasing over the past few months impacting earnings for global firms";...
                "Dividend maintained at CHF 4.00"];
else
    sentences=["Ich bin sehr glücklich.";...
            "Ich bin sehr traurig.";...
            "Eine Zange ist ein Werkzeug"];
end
%% Create Mini Batch Queue
miniBatchSize = 64;
mbqTest =  createMbqForPrediction(tokenizer, sentences, miniBatchSize);
%% Model to GPU
% To speed up feature extraction. Convert the BERT model weights to
% gpuArray if a GPU is available.
if canUseGPU
   bertModel = dlupdate(@gpuArray, bertModel);
end
%% Forward BERT
% Convert the test sentences (sequences of BERT model token)s to a
% |N|-by-|embeddingDimension| array of feature vectors, where |N| is the
% number of test sentences and |embeddingDimension| is the dimension
% of the BERT embedding.

predictions = categorical(strings(numel(sentences),1),classes);
reset(mbqTest);
idx = 1;
while hasdata(mbqTest)
    [inputIds, attentionMask, segmentIds] = next(mbqTest);
    Y = predict(bertModel,inputIds,attentionMask,segmentIds);
    Y = softmax(Y);
    YPred = onehotdecode(Y,classes,1);
    
    offset = size(Y,2);
    predictions(idx:idx+offset-1) = YPred;
    idx = idx + offset;
end

disp("Predicted labels: ")
disp(string(predictions'))
%% Helper functions

function mbq = createMbqForPrediction(tokenizer, text, miniBatchSize)

    if isa(text, "tokenizedDocument")
        [inputIds, segmentIds] = encodeTokens(tokenizer, text);
    else
        [inputIds, segmentIds] = encode(tokenizer, text);
    end   

    endOfSentenceCode = tokenizer.SeparatorCode;
    paddingCode = tokenizer.PaddingCode;

    maxSeqLength = tokenizer.ContextSize;

    inputIdsDs = arrayDatastore(inputIds, OutputType="same"); 
    segmentIdsDs = arrayDatastore(segmentIds, OutputType="same"); 
    combinedDs = combine(inputIdsDs, segmentIdsDs);  

    mbq = minibatchqueue(combinedDs,3,... % 3 outputs: inputIds, mask, segmentIds
        MiniBatchSize=miniBatchSize, ...
        MiniBatchFcn=@(inputIds,segmentIds) textanalytics.internal.bertmodel.preprocessPredictors ...
            (inputIds, ...
             segmentIds, ...
             paddingCode, ...
             endOfSentenceCode, ...
             maxSeqLength), ...
        MiniBatchFormat=["CTB" "CTB" "CTB"]);
                       
end

